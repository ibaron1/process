param(
    [string]$ServiceAccount = "DOMAIN\svc_sql_linux",
    [string]$ServicePrincipal = "MSSQLSvc/sqlserver.domain.com",
    [string]$Realm = "DOMAIN.COM",
    [string]$KeytabPath = "C:\Temp\service.keytab",
    [string]$LinuxHost = "linux-host.domain.com",
    [string]$LinuxUser = "ec2-user",
    [string]$RemotePath = "/etc/security/keytabs/service.keytab",
    [string]$Password = "SuperSecretPass123"
)

# 1. Set password never expires
net user $ServiceAccount.Split('\')[1] /domain /expires:never

# 2. Set SPN
setspn -S "$ServicePrincipal:1433" $ServiceAccount

# 3. Create keytab
ktpass -princ "$ServicePrincipal@$Realm" `
       -mapuser $ServiceAccount `
       -pass $Password `
       -out $KeytabPath `
       -ptype KRB5_NT_PRINCIPAL `
       -crypto AES256-SHA1

# 4. Transfer to Linux
scp $KeytabPath "$LinuxUser@$LinuxHost:$RemotePath"
