#!/bin/bash

REALM="$1"                  # e.g., DOMAIN.COM
KDC="$2"                    # e.g., dc01.domain.com
SERVICE_PRINCIPAL="$3"     # e.g., MSSQLSvc/sqlserver.domain.com@DOMAIN.COM
KEYTAB_PATH="$4"           # e.g., /etc/security/keytabs/service.keytab

if [ -z "$REALM" ] || [ -z "$KDC" ] || [ -z "$SERVICE_PRINCIPAL" ] || [ -z "$KEYTAB_PATH" ]; then
    echo "Usage: $0 <REALM> <KDC> <SERVICE_PRINCIPAL> <KEYTAB_PATH>"
    exit 1
fi

# 1. Configure krb5.conf
cat <<EOF | sudo tee /etc/krb5.conf
[libdefaults]
  default_realm = $REALM
  dns_lookup_realm = false
  dns_lookup_kdc = false

[realms]
  $REALM = {
    kdc = $KDC
  }

[domain_realm]
  .$REALM = $REALM
  $REALM = $REALM
EOF

# 2. Run kinit using keytab
kinit -k -t "$KEYTAB_PATH" "$SERVICE_PRINCIPAL"

# 3. Check ticket
klist
